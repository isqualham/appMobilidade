import { StyleSheet } from "react-native";
import { theme } from "../../theme";

const { colors, spacing, radii, typography } = theme;
const { semantic, neutral, brand, feedback } = colors;
const { fontSize, fontWeight, letterSpacingEm } = typography;

export const styles = StyleSheet.create({
  // Tela
  container: {
    flex: 1,
    backgroundColor: semantic.backgroundElevated,
  },

  scrollContent: {
    flexGrow: 1,
    paddingBottom: spacing.hugePlus,
  },

  // Cabeçalho
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingTop: 54,
    paddingHorizontal: spacing.huge,
    paddingBottom: spacing.hugePlus,
  },

  backButton: {
    width: 54,
    height: 54,
    borderRadius: radii.sheet,
    borderWidth: 1.5,
    borderColor: semantic.borderDefault,
    alignItems: "center",
    justifyContent: "center",
  },

  backIcon: {
    fontSize: 36,
    lineHeight: 40,
    color: semantic.iconPrimary,
    marginTop: -3,
  },

  headerTitle: {
    flex: 1,
    marginHorizontal: spacing.md,
    fontSize: fontSize.headingLarge,
    fontWeight: fontWeight.bold,
    color: semantic.textPrimary,
    textAlign: "center",
  },

  headerSpacer: {
    width: 54,
  },

  // Trajeto: origem e destino
  routeSection: {
    flexDirection: "row",
    paddingHorizontal: spacing.huge,
    paddingTop: spacing.xxs,
    paddingBottom: spacing.hugePlus,
    borderBottomWidth: 1,
    borderBottomColor: semantic.borderDefault,
  },

  routeLine: {
    width: 30,
    alignItems: "center",
    paddingTop: 34,
    paddingBottom: spacing.huge,
    marginRight: spacing.xlPlus,
  },

  originDot: {
    width: 18,
    height: 18,
    borderRadius: radii.full,
    borderWidth: 4,
    borderColor: semantic.textPrimary,
    backgroundColor: brand.primary,
    zIndex: 1,
  },

  line: {
    width: spacing.xxs,
    height: 76,
    backgroundColor: semantic.textPrimary,
  },

  destinationSquare: {
    width: 18,
    height: 18,
    borderRadius: radii.xs,
    borderWidth: 4,
    borderColor: semantic.textPrimary,
    backgroundColor: brand.primary,
  },

  routeFields: {
    flex: 1,
    gap: spacing.xxxxxl - spacing.xs,
  },

  // Campo de origem
  originField: {
    minHeight: 76,
    justifyContent: "center",
    paddingHorizontal: spacing.xxxxxl,
    paddingVertical: spacing.xl,
    borderRadius: radii.cardLarge,
    borderWidth: 1.5,
    borderColor: semantic.borderDefault,
    backgroundColor: semantic.backgroundPrimary,
  },

  fieldLabel: {
    fontSize: fontSize.subtitleSmall,
    color: semantic.textSecondary,
    marginBottom: spacing.sm + spacing.xxs,
  },

  originValue: {
    fontSize: fontSize.metric + 1,
    fontWeight: fontWeight.bold,
    color: semantic.textPrimary,
  },

  // Campo de destino
  destinationField: {
    minHeight: 76,
    flexDirection: "row",
    alignItems: "center",
    paddingLeft: spacing.xxxxxl,
    paddingRight: spacing.xl,
    borderRadius: radii.cardLarge,
    borderWidth: 2.5,
    borderColor: semantic.textPrimary,
    backgroundColor: semantic.backgroundElevated,
  },

  destinationFieldSelected: {
    borderColor: semantic.actionPositive,
  },

  destinationInputContent: {
    flex: 1,
    paddingVertical: spacing.lg,
  },

  input: {
    padding: spacing.none,
    fontSize: fontSize.metric + 1,
    fontWeight: fontWeight.bold,
    color: semantic.textPrimary,
  },

  searchIconButton: {
    width: 36,
    height: 42,
    alignItems: "center",
    justifyContent: "center",
  },

  searchIcon: {
    fontSize: 32,
    lineHeight: 36,
    color: semantic.iconPrimary,
  },

  clearButton: {
    width: 34,
    height: 42,
    alignItems: "center",
    justifyContent: "center",
  },

  clearButtonText: {
    fontSize: 27,
    color: semantic.textSecondary,
  },

  searchHint: {
    fontSize: fontSize.bodySmall + 2,
    color: semantic.textSecondary,
    paddingHorizontal: spacing.xs,
  },

  // Histórico e resultados
  historySection: {
    paddingHorizontal: spacing.hugePlus,
    paddingTop: spacing.massive,
  },

  sectionTitle: {
    fontSize: fontSize.subtitleSmall,
    fontWeight: fontWeight.extrabold,
    letterSpacing: letterSpacingEm.labelWide * 10,
    color: neutral.muted,
    marginBottom: spacing.xxxxxl - spacing.xs,
  },

  historyLoading: {
    marginTop: spacing.hugePlus,
  },

  recentRow: {
    minHeight: 100,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xxxxxl - spacing.xs,
    paddingVertical: spacing.xxxxxl - spacing.xs,
    borderBottomWidth: 1,
    borderBottomColor: semantic.borderDefault,
  },

  recentIcon: {
    width: 60,
    height: 60,
    borderRadius: radii.card,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: semantic.backgroundPrimary,
  },

  recentIconText: {
    fontSize: 27,
    color: semantic.iconPrimary,
  },

  recentTextContainer: {
    flex: 1,
    gap: spacing.sm + spacing.xxs,
  },

  recentTitle: {
    fontSize: fontSize.metric + 1,
    fontWeight: fontWeight.bold,
    color: semantic.textPrimary,
  },

  recentAddress: {
    fontSize: fontSize.subtitleSmall,
    lineHeight: 18,
    color: semantic.textSecondary,
  },

  recentArrow: {
    fontSize: 30,
    color: semantic.iconPrimary,
  },

  resultRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xl,
    paddingVertical: spacing.xxxxxl - spacing.xs,
    borderBottomWidth: 1,
    borderBottomColor: semantic.borderDefault,
  },

  resultRowSelected: {
    backgroundColor: feedback.successSoft,
  },

  placeIcon: {
    width: 48,
    height: 48,
    borderRadius: radii.card,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: semantic.backgroundPrimary,
  },

  placeIconText: {
    fontSize: 24,
    color: semantic.actionPositive,
  },

  resultTextContainer: {
    flex: 1,
    gap: spacing.xs + 1,
  },

  resultTitle: {
    fontSize: fontSize.metric,
    fontWeight: fontWeight.bold,
    color: semantic.textPrimary,
  },

  resultAddress: {
    fontSize: fontSize.subtitleSmall,
    lineHeight: 18,
    color: semantic.textSecondary,
  },

  resultArrow: {
    fontSize: 28,
    color: semantic.iconPrimary,
  },

  // Mensagens e estados vazios
  feedback: {
    alignItems: "center",
    paddingHorizontal: spacing.xxxxxl - spacing.xs,
    paddingVertical: spacing.massivePlus - spacing.xs,
  },

  feedbackTitle: {
    fontSize: fontSize.headingSmall - 1,
    fontWeight: fontWeight.bold,
    color: semantic.textPrimary,
    marginBottom: spacing.md,
  },

  feedbackText: {
    fontSize: fontSize.subtitle,
    lineHeight: 20,
    color: semantic.textSecondary,
    textAlign: "center",
    marginTop: spacing.lg,
  },

  emptyState: {
    alignItems: "center",
    paddingHorizontal: spacing.xl,
    paddingTop: 42,
  },

  emptyIcon: {
    fontSize: 42,
    color: semantic.actionPositive,
    marginBottom: spacing.xl,
  },

  emptyTitle: {
    fontSize: fontSize.headingSmall - 1,
    fontWeight: fontWeight.bold,
    color: semantic.textPrimary,
    textAlign: "center",
  },

  emptyDescription: {
    fontSize: fontSize.subtitle,
    lineHeight: 20,
    color: semantic.textSecondary,
    textAlign: "center",
    marginTop: spacing.lg - 1,
  },

  attribution: {
    fontSize: fontSize.body + 2,
    color: semantic.textSecondary,
    textAlign: "center",
    marginTop: spacing.xxxxxl + spacing.xs,
  },

  // Destino selecionado
  selectionPanel: {
    marginTop: spacing.xxxxxl,
    padding: spacing.xxxxxl - spacing.xs,
    borderRadius: radii.card,
    backgroundColor: semantic.backgroundPrimary,
  },

  selectionTitle: {
    fontSize: fontSize.metric + 1,
    fontWeight: fontWeight.bold,
    color: semantic.textPrimary,
  },

  selectionAddress: {
    fontSize: fontSize.subtitle,
    lineHeight: 19,
    color: semantic.textSecondary,
    marginTop: spacing.xs + 2,
  },

  continueButton: {
    minHeight: 52,
    marginTop: spacing.xxxxxl - spacing.xs,
    borderRadius: radii.card,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: semantic.actionPositive,
  },

  continueButtonText: {
    fontSize: fontSize.subtitle + 2,
    fontWeight: fontWeight.bold,
    color: semantic.textInverse,
  },

  // Barra inferior
  bottomBar: {
    paddingHorizontal: spacing.huge,
    paddingTop: spacing.md,
    paddingBottom: spacing.xxxxxl - spacing.xs,
    borderTopWidth: 1,
    borderTopColor: semantic.borderDefault,
    backgroundColor: semantic.backgroundElevated,
  },

  // Ações de origem
  originActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    marginTop: spacing.md,
  },

  // Escolha de destino no mapa — ação textual, sem aparência de botão
  mapPickerButton: {
    minHeight: 40,
    marginTop: spacing.md,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.md,
    backgroundColor: "transparent",
  },

  mapPickerIcon: {
    fontSize: 18,
    color: semantic.actionPositive,
  },

  mapPickerText: {
    fontSize: fontSize.button + 3,
    fontWeight: fontWeight.bold,
    color: semantic.actionPositive,
    textAlign: "center",
  },
});
