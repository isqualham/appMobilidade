import { useEffect, useRef } from "react";
import { Text, TouchableOpacity, View } from "react-native";
import { StatusBar } from "expo-status-bar";
import { router, useLocalSearchParams } from "expo-router";

import { HomeMap, type HomeMapHandle } from "./HomeMap";
import { styles } from "./HomeScreenStyles";

export function HomeScreen() {
  const homeMapRef = useRef<HomeMapHandle>(null);

  const params = useLocalSearchParams<{
    originName?: string;
    originLatitude?: string;
    originLongitude?: string;
    destinationName?: string;
    destinationAddress?: string;
    destinationLatitude?: string;
    destinationLongitude?: string;
  }>();

  const originName = params.originName;
  const originLatitude = Number(params.originLatitude);
  const originLongitude = Number(params.originLongitude);

  const hasOrigin =
    typeof originName === "string" &&
    originName.trim().length > 0 &&
    params.originLatitude !== undefined &&
    params.originLongitude !== undefined &&
    Number.isFinite(originLatitude) &&
    Number.isFinite(originLongitude) &&
    originLatitude >= -90 &&
    originLatitude <= 90 &&
    originLongitude >= -180 &&
    originLongitude <= 180;

  const destinationName = params.destinationName;
  const destinationAddress = params.destinationAddress;
  const latitude = Number(params.destinationLatitude);
  const longitude = Number(params.destinationLongitude);

  const hasDestination =
    typeof destinationName === "string" &&
    typeof destinationAddress === "string" &&
    params.destinationLatitude !== undefined &&
    params.destinationLongitude !== undefined &&
    Number.isFinite(latitude) &&
    Number.isFinite(longitude) &&
    latitude >= -90 &&
    latitude <= 90 &&
    longitude >= -180 &&
    longitude <= 180;

  useEffect(() => {
    if (!hasOrigin) return;

    homeMapRef.current?.showOrigin({
      name: originName!,
      latitude: originLatitude,
      longitude: originLongitude,
    });
  }, [hasOrigin, originName, originLatitude, originLongitude]);

  useEffect(() => {
    if (!hasDestination) return;

    homeMapRef.current?.showDestination({
      name: destinationName!,
      address: destinationAddress!,
      latitude,
      longitude,
    });
  }, [
    hasDestination,
    destinationName,
    destinationAddress,
    latitude,
    longitude,
  ]);

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />

      <View style={styles.mapContainer}>
        <HomeMap ref={homeMapRef} />

        <TouchableOpacity
          style={styles.menuButton}
          accessibilityRole="button"
          accessibilityLabel="Abrir menu"
          activeOpacity={0.7}
          onPress={() => {}}
        >
          <Text style={styles.menuIcon}>☰</Text>
        </TouchableOpacity>

        <View style={styles.locationBadge}>
          <View style={styles.locationDot} />
          <Text style={styles.locationText}>
            {hasDestination ? "Destino selecionado" : "Você está aqui"}
          </Text>
        </View>

        <TouchableOpacity
          style={styles.mapButton}
          accessibilityRole="button"
          accessibilityLabel="Centralizar mapa"
          activeOpacity={0.7}
          onPress={() => homeMapRef.current?.centerOnUserLocation()}
        >
          <Text style={styles.mapButtonIcon}>◎</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.bottomSheet}>
        <View style={styles.handle} />

        <Text style={styles.greeting}>Olá, tudo bem?</Text>

        <Text style={styles.title}>
          {hasDestination ? "Seu destino" : "Para onde vamos?"}
        </Text>

        <TouchableOpacity
          style={styles.destinationInput}
          accessibilityRole="button"
          accessibilityLabel="Digite seu destino"
          activeOpacity={0.7}
          onPress={() => router.push("/destination")}
        >
          <Text style={styles.searchIcon}>⌕</Text>

          <View style={styles.destinationTextContainer}>
            <Text style={styles.destinationPlaceholder}>
              {hasDestination ? destinationName : "Digite seu destino"}
            </Text>

            {hasDestination && (
              <Text style={styles.selectedAddress} numberOfLines={2}>
                {destinationAddress}
              </Text>
            )}
          </View>

          <Text style={styles.destinationArrow}>→</Text>
        </TouchableOpacity>

        <Text style={styles.sectionTitle}>Seus lugares</Text>

        <View style={styles.placesRow}>
          <TouchableOpacity
            style={styles.placeItem}
            activeOpacity={0.7}
            onPress={() => {}}
          >
            <View style={styles.placeIcon}>
              <Text style={styles.placeEmoji}>⌂</Text>
            </View>

            <Text style={styles.placeName}>Casa</Text>
            <Text style={styles.placeAddress}>Adicionar endereço</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.placeItem}
            activeOpacity={0.7}
            onPress={() => {}}
          >
            <View style={styles.placeIcon}>
              <Text style={styles.placeEmoji}>▣</Text>
            </View>

            <Text style={styles.placeName}>Trabalho</Text>
            <Text style={styles.placeAddress}>Adicionar endereço</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.bottomNavigation}>
        <TouchableOpacity
          style={styles.navItem}
          accessibilityRole="button"
          accessibilityLabel="Início"
          onPress={() => {}}
        >
          <Text style={styles.navIconActive}>⌂</Text>
          <Text style={styles.navTextActive}>Início</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.navItem}
          accessibilityRole="button"
          accessibilityLabel="Atividade"
          onPress={() => {}}
        >
          <Text style={styles.navIcon}>◷</Text>
          <Text style={styles.navText}>Atividade</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.navItem}
          accessibilityRole="button"
          accessibilityLabel="Carteira"
          onPress={() => {}}
        >
          <Text style={styles.navIcon}>▤</Text>
          <Text style={styles.navText}>Carteira</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.navItem}
          accessibilityRole="button"
          accessibilityLabel="Conta"
          onPress={() => {}}
        >
          <Text style={styles.navIcon}>♙</Text>
          <Text style={styles.navText}>Conta</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
